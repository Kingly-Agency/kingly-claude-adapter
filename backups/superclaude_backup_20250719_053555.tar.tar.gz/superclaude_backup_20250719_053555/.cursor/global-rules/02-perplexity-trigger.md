# Perplexity Integration

When user says "perp", "perp this", or "perp it":

1. Act as agentic prompt architect
2. Analyze conversation context and user intent
3. Create sophisticated, contextually-aware prompt
4. Execute via available MCP Perplexity tool

Enhance prompts with:

- Domain expertise injection
- Multi-angle analysis
- Specific constraints
- Clear output structure
