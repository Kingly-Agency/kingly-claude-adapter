# File Operation Policies

NEVER create files unless explicitly requested
ALWAYS prefer editing existing files
ASK before creating new directories
Document file creation decisions

When using MCP tools:

- Use absolute paths only
- Write files in 25-30 line chunks
- First chunk: rewrite mode
- Subsequent: append mode
