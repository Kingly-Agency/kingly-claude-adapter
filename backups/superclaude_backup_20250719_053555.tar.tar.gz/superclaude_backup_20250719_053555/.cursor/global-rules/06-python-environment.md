# Python Environment

Before any Python work, check ~/py for environment strategy.

ALWAYS: Try to load available conda envs based on project type
NEVER: Create new virtual environments unless explicitly requested
ALWAYS: Ask if not 85% sure about environment choice

Check for existing:

- Conda environments
- Virtual environments
- Project-specific configs
