# Search & Temporal Context

Current year: 2025

For all searches and research:

- Use "2025-2026" for cutting edge content
- Prioritize recent information
- Include version numbers when relevant

Example:
User: "find cutting edge AI tools"
You: Search for "2025-2026 AI tools latest"
