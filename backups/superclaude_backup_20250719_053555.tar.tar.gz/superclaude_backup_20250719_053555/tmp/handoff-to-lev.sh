#!/bin/bash

# Handoff script for Leviathan Adapter Build System

echo "🚀 Preparing handoff to Leviathan agent..."

# Create handoff directory in Leviathan repo
HANDOFF_DIR="$HOME/lev/workshop/adapter-build-handoff"
mkdir -p "$HANDOFF_DIR"

# Copy all handoff materials
echo "📋 Copying handoff documents..."
cp tmp/lev-adapter-build-handoff.md "$HANDOFF_DIR/"
cp tmp/conversation-insights.md "$HANDOFF_DIR/"
cp tmp/current-cursor-setup.md "$HANDOFF_DIR/"

# Copy example files for reference
echo "📁 Copying example implementations..."
cp -r .cursor/prompts "$HANDOFF_DIR/example-cursor-prompts"
cp -r .cursor/global-rules "$HANDOFF_DIR/example-cursor-rules"

# Create a quick start command
cat >"$HANDOFF_DIR/START_HERE.md" <<'EOF'
# Adapter Build System - Quick Start

## 🎯 Your Mission
Create `@lev-os/adapter-builder` core package based on the handoff materials in this directory.

## 📋 Review These Files
1. `lev-adapter-build-handoff.md` - Complete technical specification
2. `conversation-insights.md` - Key discoveries and decisions
3. `current-cursor-setup.md` - Existing implementation reference
4. `example-cursor-*` - Current Cursor/Claude integration

## 🚀 Quick Start Commands
```bash
# Navigate to packages directory
cd ~/lev/packages/

# Create the new package
mkdir adapter-builder
cd adapter-builder

# Initialize package
npm init -y

# Start implementing!
```

## 💡 Remember
- This is a CORE package with full system access
- Start with Claude Code transformer
- Test with existing intake.md example
- Keep ~/c as single source of truth

Good luck! 🚀
EOF

echo "✅ Handoff complete!"
echo ""
echo "📍 Materials location: $HANDOFF_DIR"
echo ""
echo "🤖 To start the Leviathan agent on this task:"
echo "   cd ~/lev"
echo "   cat workshop/adapter-build-handoff/START_HERE.md"
echo ""
echo "💡 The agent should begin by reviewing all materials in:"
echo "   ~/lev/workshop/adapter-build-handoff/"
